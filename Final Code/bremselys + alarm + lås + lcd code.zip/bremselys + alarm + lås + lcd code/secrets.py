# Wifi credentials
SSID = 'Bonja_Iphone'
PASSWORD = 'bonja1234'

# Server credentials
ACCESS_TOKEN = 'azm0Jq0DHOCfvryQv8JQ'
SERVER_IP_ADDRESS = 'demo.thingsboard.io'