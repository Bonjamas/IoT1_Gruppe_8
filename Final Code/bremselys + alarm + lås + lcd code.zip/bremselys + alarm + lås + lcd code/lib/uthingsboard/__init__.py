# Copyright 2021 Coredump Labs
#
# SPDX-License-Identifier: Apache-2.0

__name__ = 'uthingsboard'
__version__ = '0.2.0'
